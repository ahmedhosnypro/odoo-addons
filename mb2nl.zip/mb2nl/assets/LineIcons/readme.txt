Documentation: https://lineicons.com/usage/

License: https://lineicons.com/license/

Icons: https://lineicons.com/icons/

-------------------------------------------------

Buy Us a Coffee: http://bit.ly/donate-lineicons

It Will Encourage, Cover Running Cost and Contribute to Future Updates :)

-------------------------------------------------

LEARN MORE: https://lineicons.com