/**
 *
 * @package    local_mb2builder
 * @copyright  2018 - 2022 Mariusz Boloz (mb2moodle.com)
 * @license    Commercial https://themeforest.net/licenses
 */ define(["jquery","local_mb2builder/selectors","local_mb2builder/layoutdata"],function(e,r,a){return{saveDemo:function(){var t=e(r.builder.demoform),l=t.attr("data-url"),o=JSON.stringify(a.setData(!1));e(r.builder.demofield).val(o),e.ajax({type:"POST",url:l,data:t.serialize(),beforeSend:function(){},error:function(e,r,a){},success:function(e){}})}}});
