/**
 *
 * @package    local_mb2builder
 * @copyright  2018 - 2022 Mariusz Boloz (mb2moodle.com)
 * @license    Commercial https://themeforest.net/licenses
 */ define(["jquery","local_mb2builder/layout","local_mb2builder/helper","local_mb2builder/selectors","local_mb2builder/layoutdata"],function(t,n,e,i,a){var o=function(){t(".mb2-pb-import-select select").each(function(n){t(this).on("change",function(){var n=t(this).val();t(this).closest(".tab-pane").find(".block-item").each(function(){""===n||n===t(this).attr("data-category")?t(this).show():t(this).hide()})})})},c=function(){t(i.layout.section).each(function(){t(this).find(i.layout.row).length||t(this).find(i.layout.container_rows).html(n.startButtonsHtml())})};return{init:function(){n.layoutInit(),e.overlay(!1),e.modalSettings(),o(),c()},savePage:function(){t(".pagelayout-mb2builder_form .mform").on("submit",function(){var n=JSON.stringify(a.setData(!0));t('[name="content"]').val(n),t('[name="democontent"]').val(n)})},changeScreenSize:function(){t(document).on("click",i.builder.device,function(n){e.screenSize(t(this).attr("data-device"))})}}});
