/**
 *
 * @package    local_mb2builder
 * @copyright  2018 - 2022 Mariusz Boloz (mb2moodle.com)
 * @license    Commercial https://themeforest.net/licenses
 */ define(["jquery","local_mb2builder/selectors","local_mb2builder/helper","local_mb2builder/layoutdata"],function(a,e,t,l){var s=a(e.builder.langspan);return{savelayout:function(e){var t=e;if(!a("#savelayoutname").val()&&0==a("#editlayoutid").val())return a("#savelayoutname").css("border-color","red"),a("#savelayoutname").closest("div").find(".mb2-pb-error").show(),null;a("#savelayoutname").attr("style",""),a("#savelayoutname").closest("div").find(".mb2-pb-error").hide();var r=e.find(".btn");r.val(s.data("processing")),r.attr("disabled","disabled");var o=e.attr("data-url"),n=JSON.stringify(l.setData(!1));a("#savelayoutcontent").val(n),a.ajax({type:"POST",url:o,data:e.serialize(),beforeSend:function(){},error:function(a,e,t){a.status,a.statusText},success:function(e){setTimeout(function(){r.removeAttr("disabled"),r.val(s.data("selectlayout")),a("#savelayoutname").val(""),a("#editlayoutid").val(0),t.find(".mb2-pb-success").show(),setTimeout(function(){t.find(".mb2-pb-success").hide()},1e4)},600)}})}}});
