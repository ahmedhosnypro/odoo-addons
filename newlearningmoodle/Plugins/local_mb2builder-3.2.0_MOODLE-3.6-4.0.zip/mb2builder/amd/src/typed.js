/**
 *
 * @package    local_mb2builder
 * @copyright  2018 - 2022 Mariusz Boloz (mb2moodle.com)
 * @license    Commercial https://themeforest.net/licenses
 */ define(["jquery","theme_mb2nl/typed","local_mb2builder/selectors","local_mb2builder/helper"],function(t,e,a,n){var d=function(t){var e=t.closest(a.layout.element);return{strings:e.attr("data-typedtext").split("|"),typeSpeed:Number(e.attr("data-typespeed")),backSpeed:Number(e.attr("data-backspeed")),backDelay:Number(e.attr("data-backdelay")),loop:!0}};return{typedInit:function(a){new e("#"+a+" .typed",d(t("#"+a)))},typedDestroy:function(e){var n=t("#"+e),d=n.closest(a.layout.element);n.html(d.attr("data-content"))},beforeTypedInit:function(e){var n=t("#"+e),d=n.closest(a.layout.element);if(d.attr("data-content").includes("type")){for(var l=d.attr("data-content").split(" "),r=0;r<l.length;r++)"type"===l[r]&&(l[r]='<span class="typed"></span>');n.html(l.join(" "))}else t("#"+e).html(d.attr("data-content")+' <span class="typed"></span>')},typedPrepare:function(t){var e=n.uniqId();t.find(".heading").attr("id","typedid_"+e)}}});
