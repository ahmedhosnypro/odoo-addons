<?php
$string['configtitle'] = 'Block title';
$string['cocoon_slider_1:addinstance'] = 'Add a new [Cocoon] Slider style 1 block';
$string['cocoon_slider_1:myaddinstance'] = 'Add a new [Cocoon] Slider style 1 block to Dashboard';
$string['newcustomsliderblock'] = '[Cocoon] Slider style 1';
$string['pluginname'] = '[Cocoon] Slider style 1';
$string['slides_number'] = 'Number of slides';
