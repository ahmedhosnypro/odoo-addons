<?php

defined('MOODLE_INTERNAL') || die();

/**
 * Upgrade code for the HTML block.
 *
 * @param int $oldversion
 */
function xmldb_block_cocoon_course_feat_a_upgrade($oldversion) {
    global $CFG;

    return true;
}
