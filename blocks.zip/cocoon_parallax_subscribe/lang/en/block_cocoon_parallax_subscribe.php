<?php
$string['pluginname'] = '[Cocoon] Parallax Subscribe';
$string['cocoon_parallax_subscribe'] = '[Cocoon] Parallax Subscribe';
$string['cocoon_parallax_subscribe:addinstance'] = 'Add a [Cocoon] Parallax Subscribe block';
$string['cocoon_parallax_subscribe:myaddinstance'] = 'Add a new [Cocoon] Parallax Subscribe block to the My Moodle page';
