<?php

$string['cocoon_courses_slider:addinstance'] = 'Add a [Cocoon] Courses slider block';
$string['cocoon_courses_slider:myaddinstance'] = 'Add a [Cocoon] Courses slider block to my moodle';
$string['pluginname'] = '[Cocoon] Courses slider';
$string['editlink'] = '<a href="{$a}">Click here to edit or add featured courses</a>';
$string['editpagedesc'] = 'Editing the list of featured courses';
$string['cocoon_courses_slider'] = '[Cocoon] Courses slider';
$string['addfeaturedcourse'] = 'Add an existing course to featured list';
$string['courseid'] = 'Course';
$string['editpagetitle'] = 'Featured courses - editing';
$string['featuredcourse'] = 'Featured course: {$a}';
$string['doadd'] = 'Check to add new featured course';
$string['missingcourseid'] = 'You must select a course.';
$string['sortorder'] = 'Sort order';
$string['missingsortorder'] = 'You must set a sort order.';
$string['deletelink'] = '<a href="{$a}">Delete</a>';
$string['delete_featuredcourse'] = 'Delete featured course';
$string['confirmdelete'] = 'Are you sure you want to delete this course from the list of featured courses?';
$string['config_title'] = 'Title';
$string['config_subtitle'] = 'Subtitle';
