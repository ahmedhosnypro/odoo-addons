<?php

$string['cocoon_course_grid_5:addinstance'] = 'Add a [Cocoon] Featured Courses Masonry 3 block';
$string['cocoon_course_grid_5:myaddinstance'] = 'Add a [Cocoon] Featured Courses Masonry 3 to my moodle';
$string['pluginname'] = '[Cocoon] Featured Courses Masonry 3';
$string['cocoon_course_grid_5'] = '[Cocoon] Featured Courses Masonry 3';
$string['config_title'] = 'Title';
$string['config_subtitle'] = 'Subtitle';
$string['config_button_text'] = 'Button text';
$string['config_button_link'] = 'Button link';
$string['config_hover_text'] = 'Hover text';
$string['config_hover_accent'] = 'Hover accent';
