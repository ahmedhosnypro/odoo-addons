<?php
$string['pluginname'] = '[Cocoon] Event Body';
$string['cocoon_event_body'] = '[Cocoon] Event Body';
$string['cocoon_event_body:addinstance'] = 'Add a new Gallery block';
$string['cocoon_event_body:myaddinstance'] = 'Add a new Gallery block to the My Moodle page';
$string['config_title'] = 'Title';
$string['config_date'] = 'Date';
$string['config_image'] = 'Image';
