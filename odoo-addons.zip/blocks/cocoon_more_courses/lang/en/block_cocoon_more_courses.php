<?php

$string['cocoon_more_courses:addinstance'] = 'Add a Cocoon featured courses block';
$string['cocoon_more_courses:myaddinstance'] = 'Add a Cocoon featured courses block to my moodle';
$string['pluginname'] = '[Cocoon] Related courses';
$string['cocoon_more_courses'] = 'Cocoon featured courses';
$string['config_title'] = 'Title';
