<?php
$plugin->component = 'block_cocoon_about_2';  // Recommended since 2.0.2 (MDL-26035). Required since 3.0 (MDL-48494)
$plugin->version = 2021072620.32;
$plugin->requires = 2018051700;
